const baseURL = "http://localhost:2030";

export default baseURL;
