import React from "react";
const StripeCheckout = () => {
  const handleCheckout = () => {};
  return (
    <div>
      <button onClick={handleCheckout}>Checkout</button>
    </div>
  );
};

export default StripeCheckout;
